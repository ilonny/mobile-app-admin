#!/bin/sh
g++ -c -w -Wall ../../../libqb.cpp -D DEPENDENCY_LOADFONT -D FREEGLUT_STATIC -o libqb_setup.o

