#include <GL/freeglut.h>
#include "fg_internal.h"

void fgDeactivateMenu( SFG_Window *window ) {
  fprintf(stderr, "fgDeactivateMenu: STUB\n");
}
void fgDisplayMenu( void ) {
  fprintf(stderr, "fgDisplayMenu: STUB\n");
}
